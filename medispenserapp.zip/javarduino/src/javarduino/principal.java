package javarduino;

import java.util.logging.Level;
import java.util.logging.Logger;
import panamahitek.Arduino.PanamaHitek_Arduino;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Timer;

public class principal extends javax.swing.JFrame {
    PanamaHitek_Arduino arduino = new PanamaHitek_Arduino();
    private int contador;
    private Timer mTimer;
    private Timer mTimer2;
    private Timer mTimer3;
    private Timer mTimer4;
    private int horas = 0;
    private int minutos = 0;
    private int segundos = 0;
    private int mili = 0;
    private int horas2 = 0;
    private int minutos2 = 0;
    private int segundos2 = 0;
    private int mili2 = 0;
    private int horas3 = 0;
    private int minutos3 = 0;
    private int segundos3 = 0;
    private int mili3 = 0;
    private int horas4 = 0;
    private int minutos4 = 0;
    private int segundos4 = 0;
    private int mili4 = 0;
    private medicamentos newframe;
    private medicamentos2 newframe2;
    private medicamentos3 newframe3;
    private medicamentos4 newframe4;
    
    public principal() {
        newframe = new medicamentos(this);
        newframe2 = new medicamentos2(this);
        newframe3 = new medicamentos3(this);
        newframe4 = new medicamentos4(this);
        initComponents();
        mTimer = new Timer(10, (ActionEvent e) -> { 
            Iniciarcontar1(); 
        });
        mTimer2 = new Timer(10, (ActionEvent e) -> { 
            Iniciarcontar2(); 
        });
        mTimer3 = new Timer(10, (ActionEvent e) -> { 
            Iniciarcontar3(); 
        });
        mTimer4 = new Timer(10, (ActionEvent e) -> { 
            Iniciarcontar4(); 
        });
            
        
        try {
            arduino.arduinoTX("COM8", 9600);
        } catch (Exception ex) {
            Logger.getLogger(principal.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void Iniciarcontar1(){
        actutiempo();
        actulabel1();
    }
    
    public void Iniciarcontar2(){
        actutiempo2();
        actulabel2();
    }
    
    public void Iniciarcontar3(){
        actutiempo3();
        actulabel3();
    }
    
    public void Iniciarcontar4(){
        actutiempo4();
        actulabel4();
    }
    
//
//    
public void Iniciartemporizador() {
    mTimer.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            String num = hour.getText();
            int numero = Integer.parseInt(num);
            
            if (segundos >= numero) {
                mTimer.stop();

                horas = 0; 
                minutos = 0; 
                segundos = 0; 
                mili = 0;
                
                try{
                    arduino.sendData("A");
                }catch (Exception ex) {
                    Logger.getLogger(principal.class.getName()).log(Level.SEVERE, null,ex);
                }
                
                actutiempo();
                Iniciarcontar1();
                mTimer.start();

            }
        }
    });
    mTimer.start();
    
}

    public void Iniciartemporizador2(){
        mTimer2.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            String num2 = hour2.getText();
            int numero2 = Integer.parseInt(num2);
            
            if (segundos2 >= numero2) {
                mTimer2.stop();

                horas2 = 0; 
                minutos2 = 0; 
                segundos2 = 0; 
                mili2 = 0;
                
                try{
                    arduino.sendData("B");
                }catch (Exception ex) {
                    Logger.getLogger(principal.class.getName()).log(Level.SEVERE, null,ex);
                }

                
                actutiempo2();
                Iniciarcontar2();
                mTimer2.start();
            }
        }
    });
    mTimer2.start();
    }
    public void Iniciartemporizador3(){
        mTimer3.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            String num3 = hour3.getText();
            int numero3 = Integer.parseInt(num3);
            
            if (segundos3 >= numero3) {
                mTimer3.stop();

                horas3 = 0; 
                minutos3 = 0; 
                segundos3 = 0; 
                mili3 = 0;
                
                try{
                    arduino.sendData("C");
                }catch (Exception ex) {
                    Logger.getLogger(principal.class.getName()).log(Level.SEVERE, null,ex);
                }

                
                actutiempo3();
                Iniciarcontar3();
                mTimer3.start();
            }
        }
    });
    mTimer3.start();
    }
    public void Iniciartemporizador4(){
        mTimer4.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            String num4 = hour4.getText();
            int numero4 = Integer.parseInt(num4);
            
            if (segundos4 >= numero4) {
                mTimer4.stop();

                horas4 = 0; 
                minutos4 = 0; 
                segundos4 = 0; 
                mili4 = 0;
                
                try{
                    arduino.sendData("D");
                }catch (Exception ex) {
                    Logger.getLogger(principal.class.getName()).log(Level.SEVERE, null,ex);
                }
                
                actutiempo4();
                Iniciarcontar4();
                mTimer4.start();
            }
        }
    });
    mTimer4.start();
    }
    
//    
//    
    public void actutiempo(){
        mili++;
        
        if(mili == 100){
            mili = 0;
            segundos++;
        }
        

        if(segundos == 60) {
            segundos = 0;
            minutos++;
        }

        if (minutos == 60) {
            minutos = 0;
            horas++;
        }

    }
    public void actutiempo2(){
        mili2++;
        
        if(mili2 == 100){
            mili2 = 0;
            segundos2++;
        }
        

        if(segundos2 == 60) {
            segundos2 = 0;
            minutos2++;
        }

        if (minutos2 == 60) {
            minutos2 = 0;
            horas2++;
        }

    }
    public void actutiempo3(){
        mili3++;
        
        if(mili3 == 100){
            mili3 = 0;
            segundos3++;
        }
        

        if(segundos3 == 60) {
            segundos3 = 0;
            minutos3++;
        }

        if (minutos3 == 60) {
            minutos3 = 0;
            horas3++;
        }

    }
    public void actutiempo4(){
        mili4++;
        
        if(mili4 == 100){
            mili4 = 0;
            segundos4++;
        }
        

        if(segundos4 == 60) {
            segundos4 = 0;
            minutos4++;
        }

        if (minutos4 == 60) {
            minutos4 = 0;
            horas4++;
        }

    }
    
//    
//    
    public void actulabel1(){
        String cronometro = horas + "h:" + minutos + "m:" + segundos + "s" + "." + mili;
        crono1.setText(cronometro);
    }
    
    public void actulabel2(){
        String cronometro = horas2 + "h:" + minutos2 + "m:" + segundos2 + "s" + "." + mili2;
        crono2.setText(cronometro);
    }
    
    public void actulabel3(){
        String cronometro = horas3 + "h:" + minutos3 + "m:" + segundos3 + "s" + "." + mili3;
        crono3.setText(cronometro);
    }
    
    public void actulabel4(){
        String cronometro = horas4 + "h:" + minutos4 + "m:" + segundos4 + "s" + "." + mili4;
        crono4.setText(cronometro);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel5 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        recibe = new javax.swing.JLabel();
        hour = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        recibe2 = new javax.swing.JLabel();
        hour2 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        recibe3 = new javax.swing.JLabel();
        hour3 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        recibe4 = new javax.swing.JLabel();
        hour4 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        crono1 = new javax.swing.JLabel();
        crono2 = new javax.swing.JLabel();
        crono3 = new javax.swing.JLabel();
        crono4 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();

        jPanel5.setBackground(new java.awt.Color(204, 204, 255));

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 272, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 232, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jPanel3.setBackground(new java.awt.Color(204, 204, 255));

        jLabel1.setFont(new java.awt.Font("SansSerif", 0, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Medispenser");

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javarduino/medispenser_logo.png"))); // NOI18N

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 511, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(jLabel1)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.setBackground(new java.awt.Color(204, 204, 255));

        jPanel9.setBackground(new java.awt.Color(255, 255, 255));

        jButton1.setBackground(new java.awt.Color(204, 204, 255));
        jButton1.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
        jButton1.setText("Añadir medicamentos");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        recibe.setText("---");

        hour.setText("-");

        jLabel4.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
        jLabel4.setText("horas");

        recibe2.setText("---");

        hour2.setText("-");

        jLabel5.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
        jLabel5.setText("horas");

        recibe3.setText("---");

        hour3.setText("-");

        jLabel6.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
        jLabel6.setText("horas");

        recibe4.setText("---");

        hour4.setText("-");

        jLabel7.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
        jLabel7.setText("horas");

        crono1.setText("00 h : 00 m : 00 s . 00");

        crono2.setText("00 h : 00 m : 00 s . 00");

        crono3.setText("00 h : 00 m : 00 s . 00");

        crono4.setText("00 h : 00 m : 00 s . 00");

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addComponent(recibe, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(hour, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel4))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addComponent(recibe2, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(hour2, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel5))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addComponent(recibe3, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(hour3, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel6))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addComponent(recibe4, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(hour4, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel7)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 55, Short.MAX_VALUE)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton1)
                    .addComponent(crono1)
                    .addComponent(crono2)
                    .addComponent(crono3)
                    .addComponent(crono4))
                .addContainerGap())
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(crono1))
                    .addComponent(hour, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(recibe, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(crono2))
                    .addComponent(hour2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(recibe2))
                .addGap(18, 18, 18)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(crono3))
                    .addComponent(hour3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(recibe3))
                .addGap(18, 18, 18)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(crono4))
                    .addComponent(hour4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(recibe4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 41, Short.MAX_VALUE)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel4.setBackground(new java.awt.Color(153, 204, 255));

        jLabel3.setBackground(new java.awt.Color(153, 204, 255));
        jLabel3.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        jLabel3.setText("Medicamentos");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel3)
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(104, 104, 104)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(55, 55, 55)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(109, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

                contador++;

                // Mostrar la ventana correspondiente según el contador
                if (contador == 1) {
                    newframe.setVisible(true);
                    newframe2.setVisible(false);
                    newframe3.setVisible(false);
                    newframe4.setVisible(false);
                } else if (contador == 2) {
                    newframe.setVisible(false);
                    newframe2.setVisible(true);
                    newframe3.setVisible(false);
                    newframe4.setVisible(false);
                } else if (contador == 3) {
                    newframe.setVisible(false);
                    newframe2.setVisible(false);
                    newframe3.setVisible(true);
                    newframe4.setVisible(false);
                } else if (contador == 4) {
                    newframe.setVisible(false);
                    newframe2.setVisible(false);
                    newframe3.setVisible(false);
                    newframe4.setVisible(true);
                }


    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new principal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel crono1;
    private javax.swing.JLabel crono2;
    private javax.swing.JLabel crono3;
    private javax.swing.JLabel crono4;
    public static javax.swing.JLabel hour;
    public static javax.swing.JLabel hour2;
    public static javax.swing.JLabel hour3;
    public static javax.swing.JLabel hour4;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel9;
    public static javax.swing.JLabel recibe;
    public static javax.swing.JLabel recibe2;
    public static javax.swing.JLabel recibe3;
    public static javax.swing.JLabel recibe4;
    // End of variables declaration//GEN-END:variables
}
